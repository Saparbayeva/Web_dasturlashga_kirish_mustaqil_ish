<?php 
include('connection.php');
if(isset($_POST['login'])
 && $_POST['password']){
    $login = $_POST['login'];
    $password = $_POST['password'];
    $sql1 = "SELECT * from user where login='$login' and password='$password' " ;
    $result = $connection->prepare($sql1);
    $result->bind_param('ss',$login,$password);
    $result->execute();
    $row = mysql_fetch_assoc($result);

    header('Location: admin.php');
}
 else{
echo "Login yoki parol kiritilmagan!" ;
 }
?>
<html>
    <head>
        <title>Login</title> 
    </head>
    <body>
<h1>Login oynasi</h1>

<form action="" method="post"> 

<div class="form-group row">
    <label for="login" class="col-sm-2 col-form-label">Password</label>
    <div class="col-sm-10">

      <input name="login" type="password" class="form-control" id="login" placeholder="login">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
    <div class="col-sm-10">

      <input name="password" type="password" class="form-control" id="inputPassword" placeholder="Password">
    </div>
  </div>

  <button class="btn btn-primary" type="submit" name="s1">Save</button>
</form>
    </body>
</html>