<?php
include 'connection.php';
$id = $_POST['id'];
$sql = "DELETE FROM team where id='$id'";
if ($connection->query($sql) === TRUE) {
    header("Location:team.php");
} else echo $connection->error;
