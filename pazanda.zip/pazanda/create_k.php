<?php

include 'connection.php';
if (isset($_POST['s1'])) {

    $name = $_POST['name'];
  
    $sql = "INSERT INTO category( `name`) VALUES ('{$name}')";
    if ($connection->query($sql)) 
    {
        ?>
      <script type="javascript">alert("Saqlandi")</script>
      <?php
        header("Location:category.php");
    } else echo 'xato!' . $connection->error;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <title>Kategoriya qo'shish</title>
</head>
<body>
<div class="text-left">
        <a href="admin.php" style="color: #9F0053" class="btn btn-block mb-2 "><h3>Admin menyuga qaytish</h3></a>
    </div>
    <h2 align="center">Kategoriya qo'shish  oynasi</h2>

<form action="" method="post">
<div class="form-group">
    <label for="name">name </label>
    <input type="text" class="form-control" id="name"  name="name">
  </div>
  <button class="btn btn-primary" type="submit" name="s1">Save</button>
</form>
</body>
</html>