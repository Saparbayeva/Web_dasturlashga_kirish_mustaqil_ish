<?php
include 'connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

    <title>Foods </title>
    <style>
        
button{
margin-left: 30px;
}
a{
    text-decoration: none;
   color: black;
}
    </style>
</head>
<body>



 <nav class="navbar navbar-dark bg-primary">
  <!-- Navbar content -->
<form class="form-inline">

    <button class="btn btn-success" type="button"><a href="admin.php">
    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="16" fill="currentColor" class="bi bi-arrow-left-square" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M15 2a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2zM0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2zm11.5 5.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z"/>
</svg> Admin panel</a> </button>
    <button class="btn btn-success" type="button"><a href="./category.php" >Categoriyalar</a>  </button>
    <button class="btn btn-success" type="button"><a href="food.php" >Food oynasi </a> </button>
    <button class="btn btn-success" type="button"><a href="team.php" >Team oynasi </a> </button>
    <button class="btn btn-success" type="button"><a href="user.php" >User oynasi </a> </button>
    <button class="btn btn-sm btn-secondary" type="button"><a href="create_f.php">
    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="16" fill="currentColor" class="bi bi-arrow-left-square" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M15 2a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2zM0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2zm11.5 5.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z"/>
</svg> food create</a></button>
  </form>  
</nav>
<center>
    <h2 style="color: #00a8c6"  >
  Foods
    </h2>
    </center> 
<nav class="navbar navbar-expand-lg navbar-light bg-info">

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <?php $sql = "SELECT * FROM category";
        $result = $connection->query($sql);
        if($result->num_rows>0){
            while($row = $result->fetch_assoc())

            {
                ?>
        <ul class="navbar-nav">

                <a class="nav-link" href="#"><b><?php echo $row['name']?> </b><span class="sr-only">(current)</span></a>
        </ul>

        <?php
        }
        }
        ?>
</div>
</nav> 

<table class="table table-hover">
        <thead>
        <tr>
            <th>ID</th>
            <th>category</th> 
            <th>nomi</th>
            <th>recipe</th>
            <th>price</th>
            <th>image</th>
            <th>edit</th>
            <th>delete</th>
        </tr>
        </thead>
        <tbody>
        <?php $sql = "SELECT * FROM food";
        $result = $connection->query($sql);
        if($result->num_rows>0){
            while($row = $result->fetch_assoc())
            {
                ?>
                <tr>
<!--                    <td>--><?php echo $row['id']?><!--</td>-->
                    <td><?php echo $row['id']?></td>
                    <td><?php echo $row['category']?></td>
                    <td><?php echo $row['name']?></td>
                    <td><?php echo $row['recipe']?></td>
                    <td><?php echo $row['price']?></td>
                    <td><img src="image/<?php echo $row['image']?>" alt="" width="250px" height="150px"></td>
                    </td>

                    <td>  <form action="edit_f.php" methog="GET">
                            <input type="hidden" name="id" value="<?php echo($row['id'])?>">
                            <button type="submit" class="btn btn-primary">O'zgartirish</button>
                        </form>
                    </td>

                    <td>
                        <form action="delete_f.php" method="post">
                            <input type="hidden" name="id" value="<?php echo($row['id'])?>">
                            <button type="submit" class="btn btn-danger">O'chirish</button>

                        </form>

                    </td>
                </tr>
            <?php }}?>
        </tbody>
    </table>

</body>
</html>