<?php
include 'connection.php';
if (isset($_POST['s1'])) {
    $name = $_POST['name'];
    $tel = $_POST['tel'];
    $tg = $_POST['tg'];
    $facebooc = $_POST['facebooc'];
    $job = $_POST['job'];
//rasm uchun
$filename = $_FILES["image"]["name"];
$tempname = $_FILES["image"]["tmp_name"];
$folder = "image/" . $filename;
if(move_uploaded_file($tempname,$folder)){
    echo "rasm yuklandi!";
}
else echo "rasm yuklashda xatolik";
    $sql = "INSERT INTO `team`(`name`, `tel`, `tg`, `facebooc`, `job`, `image`) 
    VALUES (' $name','$tel',' $tg','$facebooc','$job','$filename')";
    if ($connection->query($sql)) 
    {
        ?>
      <script type="javascript">alert("Saqlandi")</script>
      <?php
        header("Location:team.php");
    } else echo 'xato!' . $connection->error;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <title>Kategoriya qo'shish</title>
</head>
<body>
<div class="text-left">
        <a href="admin.php" style="color: #9F0053" class="btn btn-block mb-2 "><h3>Admin menyuga qaytish</h3></a>
    </div>
    <h2 align="center">create  Teams
    </h2>

<form action="" method="post" enctype="multipart/form-data">
   
  <div class="form-group">
    <label for="name">name </label>
    <input type="text" class="form-control" id="name"  name="name">
  </div>

  <div class="form-group">
    <label for="tel">tel </label>
    <input type="text" class="form-control" id="tel"  name="tel">
  </div>

  <div class="form-group">
    <label for="tg">tg </label>
    <input type="text" class="form-control" id="tg"  name="tg">
  </div>

  <div class="form-group">
    <label for="facebooc">facebooc </label>
    <input type="text" class="form-control" id="facebooc"  name="facebooc">
  </div>

  <div class="form-group">
    <label for="job">job </label>
    <input type="text" class="form-control" id="job"  name="job">
  </div>

  <div class="form-group">
    <label for="image">image</label>
    <input type="file" class="form-control" id="image"  name="image">
  </div>


  <button class="btn btn-primary" type="submit" name="s1">Save</button>
</form>
</body>
</html>