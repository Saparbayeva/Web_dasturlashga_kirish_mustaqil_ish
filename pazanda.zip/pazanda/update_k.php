<?php
include 'connection.php';

if (isset($_POST['name'])){
    $name= $_POST['name'];
   
    $id = intval($_POST['id']);
   

    $sql = "UPDATE category SET  name='$name' WHERE id = '$id';";
    if ($connection->query($sql)) {
        header('Location: category.php');
    } else echo 'xato!' . $connection->error;
}
$connection->close();
