<?php
include 'connection.php';
if (isset($_POST['s1'])) {
    $category = $_POST['category'];
    $name = $_POST['name'];
    $recipe = $_POST['recipe'];
    $price = $_POST['price'];
//rasm uchun
$filename = $_FILES["image"]["name"];
$tempname = $_FILES["image"]["tmp_name"];
$folder = "image/" . $filename;
if(move_uploaded_file($tempname,$folder)){
    echo "rasm yuklandi!";
}
else echo "rasm yuklashda xatolik";

    $sql = "INSERT INTO `food`(`category`, `name`, `recipe`, `price`, `image`) 
    VALUES (' $category',' $name','$recipe',' $price','$filename')";
    if ($connection->query($sql)) 
    {
        ?>
      <script type="javascript">alert("Saqlandi")</script>
      <?php
        header("Location:food.php");
    } else echo 'xato!' . $connection->error;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <title>Kategoriya qo'shish</title>
</head>
<body>
<div class="text-left">
        <a href="admin.php" style="color: #9F0053" class="btn btn-block mb-2 "><h3>Admin menyuga qaytish</h3></a>
    </div>
    <h2 align="center">create food
    </h2>

<form action="" method="post" enctype="multipart/form-data">
    <div class="form-group">
            <label for="category">kategoriya tanlang</label>
            <select name="category" id="category" class="form-control">
                <?php
                $sql_category = "SELECT * FROM category";
                $result_category = $connection->query($sql_category);
                if($result_category->num_rows>0){
                    while($row_category = $result_category->fetch_assoc())
                    {
                  
                        ?>

                        <option value="<?=$row_category['id']?>">
                            <?php echo $row_category['name']?> </option>
                        <?php
                    }}
                ?>
            </select>
        </div>

  <div class="form-group">
    <label for="name">name </label>
    <input type="text" class="form-control" id="name"  name="name">
  </div>

  <div class="form-group">
    <label for="recipe">recipe </label>
    <input type="text" class="form-control" id="recipe"  name="recipe">
  </div>

  <div class="form-group">
    <label for="price">price </label>
    <input type="text" class="form-control" id="price"  name="price">
  </div>

  <div class="form-group">
    <label for="image">image</label>
    <input type="file" class="form-control" id="image"  name="image">
  </div>


  <button class="btn btn-primary" type="submit" name="s1">Save</button>
</form>
</body>
</html>