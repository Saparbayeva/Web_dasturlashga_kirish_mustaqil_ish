<?php
include 'connection.php';
if (isset($_POST['name']) 
&& isset($_POST['tel'])  
&& isset($_POST['tg']) 
&& isset($_POST['facebooc'])
&& isset($_POST['job'])  

) {
    $tel = $_POST['tel'];
    $name = $_POST['name'];
    $tg = $_POST['tg'];
    $job = $_POST['job'];
    $facebooc = $_POST['facebooc'];
//rasm uchun
$filename = $_FILES["image"]["name"];
$tempname = $_FILES["image"]["tmp_name"];
$folder = "image/" . $filename;
if(move_uploaded_file($tempname,$folder)){
    echo "rasm yuklandi!";
}
else echo "rasm yuklashda xatolik";

    $id = intval($_POST['id']);
    $sql = "UPDATE team SET  tel='$tel', name='$name', tg='$tg', facebooc='$facebooc', job='$job', image='$filename'   
       WHERE id = '$id';";
    if ($connection->query($sql)) {
        header('Location: team.php'); 
    } else echo 'xato!' . $connection->error;
}

$connection->close();
