<?php
include 'connection.php';
$id=$_GET['id'];

$sql="SELECT * FROM `food` where id='$id'";
$result=$connection->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <title>Edit food</title>
</head>
<body>
<div class="container">

    <div class="row" style="width: 45rem ;" align="center">
        <div class="col-md-12 offset-md-3" style="color: #00a8c6" align="center">
            <h2 align="center">O'zgartirish</h2>
            <form action="update_f.php" method="post" enctype="multipart/form-data">
                <?php
               if($result->num_rows>0){
                    while ($row=$result->fetch_assoc()){
                        ?>
                        <input type="hidden" name="id" value="<?php echo $row['id'] ?>">

                        <div class="form-group">
            <label for="category">kategoriya tanlang</label>
            <select name="category" id="category" class="form-control">
                <?php
                $sql_category = "SELECT * FROM category";
                $result_category = $connection->query($sql_category);
                if($result_category->num_rows>0){
                    while($row_category = $result_category->fetch_assoc())
                    {
                        ?>
                        <option value="<?=$row_category['id']?>">
                            <?php echo $row_category['name']?> </option>
                        <?php
                    }}
                ?>
            </select>
        </div>

                        <div class="form-group">
                            <label for="name">name</label>
                            <input type="text" class="form-control"  value="<?php echo $row['name'] ?>"  name="name" id="name" required>
                        </div>

                        <div class="form-group">
                            <label for="recipe">Category recipe </label>
                            <input type="text" class="form-control"  value="<?php echo $row['recipe'] ?>"  name="recipe" id="recipe" required>
                        </div>

                        <div class="form-group">
                            <label for="price">Category price </label>
                            <input type="text" class="form-control"  value="<?php echo $row['price'] ?>"  name="price" id="price" required>
                        </div>

                        <div class="form-group">
                            <label for="image">Category image </label>
                            <input type="file" class="form-control"  value="<?php echo $row['image'] ?>"  name="image" id="image" >
                        </div>



                        <input type="submit" value="saqlash" name="s2" class="btn btn-primary">
                        <?php
                    }}
                ?>
            </form>
        </div>
</body>
</html>