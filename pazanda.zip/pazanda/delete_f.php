<?php
include 'connection.php';
$id = $_POST['id'];
$sql = "DELETE FROM food where id='$id'";
if ($connection->query($sql) === TRUE) {
    header("Location:food.php");
} else echo $connection->error;
